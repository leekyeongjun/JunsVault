package Assignment7;

public class Gyeonggi extends Hub {
    private static int init_num = 10000;
    private static final String init_area = "Gyeonggi";
    private static final double init_price_per_box = 3150.0;
    public Gyeonggi(String description) {
        setNumber(++init_num);
        setDescription(description);
        setArea(init_area);
        setPrice_per_box(init_price_per_box);
    }
}
