package Assignment7;
import java.util.ArrayList;
import java.util.Scanner;

public class Logistics {
    public static void main(String[] args) {
        String[] new_gyeonggi_boxes = {"SuWon#1","SeongNam#1","YongIn#1","GoSeong#1","GaPyeong#1"};
        String[] new_gangwon_boxes = {"Gangneung#1","Wonju#1"};
        ArrayList<Gyeonggi> gyList = new ArrayList<>();
        ArrayList<Gangwon> gaList = new ArrayList<>();

        Scanner scan = new Scanner(System.in);

        // Gyeonggi 와 Gangwon 의 box String 목록을 모두 인스턴스화해서 ArrayList에 넣는다.
        ServiceManagement.packageBoxes(new_gyeonggi_boxes, Gyeonggi.class, gyList);
        ServiceManagement.packageBoxes(new_gangwon_boxes, Gangwon.class, gaList);

        System.out.println("*** Oh, delivery price has been increased!! ***");
        // Gyeonggi 와 Gangwon 의 배송 요금을 모두 5% 인상한다.
        ServiceManagement.raiseAll(Gyeonggi.class, gyList, 1.05);
        ServiceManagement.raiseAll(Gangwon.class, gaList, 1.05);

        System.out.println("Which box is important in Gangwon-area?");
        // 콘솔 입력을 통해 정수값 id를 받아서 Gangwon arraylist에서 index를 찾는다.
        int num = scan.nextInt();
        int index = ServiceManagement.findIndexByNum(gaList, num);

        if(index == -1) {
            System.out.println("nothing");
        } else {
            System.out.println("The box \""+gaList.get(index).getDescription()+"\" is important! be careful!\n");
            // 반환된 index의 해당 box 요금을 20% 인상한다.
            ServiceManagement.raisePerBox(gaList.get(index), 1.20);
        }

        System.out.println("Which box has the wrong area in Gyeonggi-area?");
        // 콘솔 입력을 통해 정수값 id를 받아서 Gyeonggi arraylist에서 index를 찾는다.
        num = scan.nextInt();
        index = ServiceManagement.findIndexByNum(gyList, num);

        if(index == -1) {
            System.out.println("nothing");
        } else {
            System.out.println("The box \"" + gyList.get(index).getDescription()
            + "\" is actually has to go to Gangwon! late! hurry up!\n");
            // gyList에서 반환된 index에 해당하는 box의 목적 허브를 "Gangwon"으로 변경한다.
            ServiceManagement.changeHub(gyList, index, Gangwon.class, gaList);
            // 지연 배송에 대한 discount로 box의 요금을 10% 할인한다.
            ServiceManagement.raisePerBox(gaList.get(gaList.size() - 1), 0.9);
        }
        for(Gyeonggi g : gyList) {
            if(g != null) {
                System.out.println(g+"\n");
            }
        }
        for(Gangwon j : gaList) {
            System.out.println(j+"\n");
        }
        scan.close();
    }
}
