package Assignment7;

import java.util.ArrayList;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

public class ServiceManagement {
    public static <T extends Hub> int findIndexByNum(ArrayList<T> tList, int num) {
        for (int i = 0; i < tList.size(); i++) {
            if (tList.get(i).getNumber() == num) { return i; }
        }
        return -1;}
    public static <T extends Hub> T raisePerBox(T t, double rate) {
        t.setPrice_per_box(t.getPrice_per_box() * rate);
        return t;}
    public static <T extends Hub> ArrayList<T> raiseAll(Class<T> c, ArrayList<T> tList, double rate) {
        for (T elem : tList) {elem.setPrice_per_box(rate * elem.getPrice_per_box());}
        try {
            Field f = c.getDeclaredField("init_price_per_box");
            f.setAccessible(true);
            double value = f.getDouble(null);
            f.setDouble(null, value * rate);
        } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {e.printStackTrace();}
        return tList;
    }

    public static <T extends Hub> void packageBoxes(String[] descriptions, Class<T> classType, ArrayList<T> tList) {
        try {
            Constructor<T> constructor = classType.getConstructor(String.class);
            for (String description : descriptions) {
                T instance = constructor.newInstance(description);
                tList.add(instance);
            }
        } catch (Exception e) {e.printStackTrace();}
    }

    public static <T extends Hub, U extends Hub> void changeHub(ArrayList<T> tList, int index, Class<U> classType, ArrayList<U> uList) {
        try {
            if (index >= 0 && index < tList.size()) {
                T target = tList.get(index);
                String description = target.getDescription();
                Constructor<U> constructor = classType.getConstructor(String.class);
                U newInstance = constructor.newInstance(description);
                uList.add(newInstance);
                tList.set(index, null);
            }
        } catch (Exception e) { e.printStackTrace();}
    }
}
