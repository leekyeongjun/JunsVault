package Assignment7;

public class Gangwon extends Hub {
    private static int init_num = 20000;
    private static final String init_area = "Gangwon";
    private static final double init_price_per_box = 3150.0;

    public Gangwon(String description) {
        setNumber(++init_num);
        setDescription(description);
        setArea(init_area);
        setPrice_per_box(init_price_per_box);
    }
}