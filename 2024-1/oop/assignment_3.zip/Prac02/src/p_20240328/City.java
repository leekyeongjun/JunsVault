package p_20240328;
import java.util.Random;
import java.lang.Math;

public class City {
	private String name;
	private Integer locationX;
	private Integer locationY;
	
	public static double distance(City A, City B) {
		double dis;
		dis = Math.sqrt(Math.pow((A.locationX.doubleValue())-(B.locationX.doubleValue()),2)
				+ Math.pow((A.locationY.doubleValue())-(B.locationY.doubleValue()),2));
		System.out.println(A.name + "-"+ B.name+ " : " + dis);
		return dis;
	}
	public City(String _name, Integer loX, Integer loY) {
		name = _name;
		locationX = loX;
		locationY = loY;
	}
	public City(String _name) {
		name = _name;
		Random rnd = new Random();
		locationX = rnd.nextInt(361);
		locationY = rnd.nextInt(361);
	}
	
	public String GetCityName() {
		return name;
	}
	public int GetCityLoX() {
		return locationX;
	}
	public int GetCityLoY(){
		return locationY;
	}
	
	public boolean equals(City c) {
		if(c.name == name && locationX == c.locationX && locationY == c.locationY) {
			return true;
		}
		else return false;
	}
	
	public String toString() {
		return name+ ", " + GetCityLoX() + ", " + GetCityLoY();
	}
}
