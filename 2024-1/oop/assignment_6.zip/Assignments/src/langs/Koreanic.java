package langs;

public class Koreanic extends Language{
	Koreanic(String _name, int numSpeakers){
		super(_name, numSpeakers, "","");
		String regionSpoken = "Korean peninsula(South Korea, North Korea, Jeju) and several prefectures of China";
		String wordOrder = "subject-object-verb";
		
		if(this.name.contains("Jeju")) {
			regionSpoken = "Jeju Island";
		}
		
		this.regionSpoken = regionSpoken;
		this.wordOrder = wordOrder;
	}
}
