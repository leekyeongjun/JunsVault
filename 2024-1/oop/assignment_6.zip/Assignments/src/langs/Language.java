package langs;

public class Language {
	protected String name;
	protected Integer numSpeakers;
	protected String regionSpoken;
	protected String wordOrder;
	
	Language(String _name, int _numSpeakers, String _regionSpoken, String _wordOrder){
		name = _name;
		numSpeakers = _numSpeakers;
		regionSpoken = _regionSpoken;
		wordOrder = _wordOrder;
	}
	
	public void getInfo() {
		String buf = 
		name + " is spoken by " + numSpeakers + " people mainly in " + regionSpoken +  ".\n" +
		"The language follows the word order: "+ wordOrder + ".";
		
		System.out.println(buf);
	}
	
	public static void main(String[] args) {
		System.out.println("---------- Language ----------");
		Language spanish = new Language(
		"Spanish",
		555000000,
		"Spain, Latin America, and Equatorial Guinea",
		"subject-verb-object");
		spanish.getInfo();
		System.out.println("----------Koreanic----------");
		Language korean = new Koreanic("Korean", 80400000);
		korean.getInfo();
		Language jeju_uh = new Koreanic("Jeju Language", 695500);
		jeju_uh.getInfo();
		System.out.println("----------Mayan----------");
		Mayan kiche = new Mayan("Ki'che'", 2330000);
		kiche.getInfo();
	}

}
