package Exception_handling;
public class TooMuchExpenseException extends Exception {
    private int inputNum; // instance variable

    // 인자가 없는 생성자
    public TooMuchExpenseException() {
        super("Not enough balance.");
    }

    // int 인자를 받는 생성자
    public TooMuchExpenseException(int inputNum) {
        super("Over the limit!");
        this.inputNum = inputNum;
    }

    // inputNum을 반환하는 getter
    public int getInputNum() {
        return inputNum;
    }
}

