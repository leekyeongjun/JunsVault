package Exception_handling;
import java.util.Scanner;

public class Market {
    public static void main(String[] args) {
        Wallet wallet = new Wallet("User"); // 지갑 객체 생성
        Scanner scanner = new Scanner(System.in);

        while (true) {
            try {
                wallet.empty(); // 지갑 잔고 체크

                System.out.print("Enter price: "); // 사용자로부터 금액 입력 받음
                int expense = scanner.nextInt();

                if (expense < 0) {
                    throw new NegativeException();
                } else if (expense > 100) {
                    throw new TooMuchExpenseException(expense);
                } else if (expense > wallet.getBalance()) {
                    throw new TooMuchExpenseException();
                } else {
                    wallet.increaseIndex(); // 인덱스 증가
                    wallet.decreaseBalance(expense); // 잔고 감소
                }
            } catch (NegativeException e) {
                System.out.println(e.getMessage());
            } catch (TooMuchExpenseException e) {
                if (e.getMessage().equals("Over the limit!")) {
                    System.out.println("you pay " + e.getInputNum());
                } else {
                    System.out.println(e.getMessage());
                }
            } catch (Exception e) {
                if (e.getMessage().equals("Go Home")) {
                    System.out.println(e.getMessage());
                    scanner.close(); // Scanner 객체 닫기
                    return; // 프로그램 종료
                }
            } finally {
                System.out.println(wallet.toString()); // 지갑의 현재 잔고 출력
                System.out.println("---transaction complete---\n"); // 트랜잭션 완료 메시지 출력
            }
        }
    }
}
