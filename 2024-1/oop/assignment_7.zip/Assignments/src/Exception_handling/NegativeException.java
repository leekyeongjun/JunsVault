package Exception_handling;

public class NegativeException extends Exception {
    // 인자가 없는 생성자
    public NegativeException() {
        super("price must be positive");
    }

    // String 인자를 받는 생성자
    public NegativeException(String message) {
        super(message);
    }
}
