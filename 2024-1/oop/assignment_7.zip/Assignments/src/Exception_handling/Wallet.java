package Exception_handling;

public class Wallet {
    private String name;
    private int balance;
    private int txIndex;

    // name을 인자로 받고 instance variable의 값을 초기화하는 생성자
    public Wallet(String name) {
        this.name = name;
        this.txIndex = 0;
        this.balance = 100;
    }

    // balance에 대한 getter
    public int getBalance() {
        return balance;
    }

    // txIndex를 1만큼 증가시키는 method
    public void increaseIndex() {
        this.txIndex++;
    }

    // balance를 expense 만큼 감소시키는 method
    public void decreaseBalance(int expense) throws NegativeException {
        if(expense < 0) {
            throw new NegativeException();
        }
        this.balance -= expense;
    }

    // toString method
    @Override
    public String toString() {
        return "name: " + this.name + ", #" + this.txIndex + ", balance: " + this.balance;
    }

    // 지갑에 돈이 없으면 집에 가야하는 메소드
    public void empty() throws Exception {
        if(this.balance <= 0) {
            throw new Exception("Go Home");
        }
    }
}

