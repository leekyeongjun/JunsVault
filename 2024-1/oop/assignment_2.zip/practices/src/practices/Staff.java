package practices;
import java.util.Scanner;


public class Staff {
	private String Name;
	private int Age;
	private String Department;
	private int Workdays;
	private int VacationDays;
	
// constructors
	public Staff(String _Name, int _Age){
		Name = _Name;
		Age = _Age;
		Department = "None";
		Workdays = 0;
		VacationDays = 20;
	}
	
	public Staff(String _Name, int _Age, String _Department, int _Workdays, int _VacationDays) {
		Name = _Name;
		Age = _Age;
		Department = _Department;
		Workdays = _Workdays;
		VacationDays = _VacationDays;		
	}
// getter
	public String GetName() {
		String name;
		name = this.Name;
		return name;
	}
	
	public boolean SameCareer(Staff a) {
		System.out.print(this.GetName() + " and " + a.GetName() + ",");
		if (this.Department.equals(a.Department) && this.Workdays == a.Workdays) {
			System.out.println(" Same.");
			return true;
		}
		else {
			System.out.println(" Not exactly same.");
			return false;
		}
	}
// setter
	public void SetCareer(String _Department, int _Workdays) {
		this.Department = _Department;
		this.Workdays = _Workdays;
	}
	

	
	public void Vacation(int amount) {
		if((this.VacationDays - amount) >= 0 ) {
			System.out.print(GetName() + ", 휴가 " + amount + " 사용. ");
			this.VacationDays -= amount;
			System.out.println( "남은 휴가 일수: " + this.VacationDays);
		}
		else {
			System.out.println( GetName() + ", 남은 휴가 일수 부족");
		}
	}

// toString	
	public String toString() {
		String ret;
		ret = "Name: " + GetName() + ", Age: " + this.Age + ", Department: " + this.Department + ", workDays: "+ this.Workdays+ ", VacationDays: " + this.VacationDays;
		return ret;
	}
}
