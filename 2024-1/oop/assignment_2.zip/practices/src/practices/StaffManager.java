package practices;
import practices.Staff;

public class StaffManager {
	public static void main(String[] args) {
		Staff James = new Staff("James Wright", 29, "Accounting", 365, 15);
		Staff Peter = new Staff("Peter Coolidge", 32, "R&D", 1095, 7);
		Staff Amy = new Staff("Amy Smith", 27);
		
		System.out.println(James.toString());
		System.out.println(Peter.toString());
		System.out.println(Amy.toString());
		System.out.println("---");
		
		System.out.println("Same Career?");
		Peter.SameCareer(Amy);
		System.out.println("...A Few years later...");
		Amy.SetCareer("R&D", 1095);
		Peter.SameCareer(Amy);
		System.out.println("---");
		
		James.Vacation(10);
		Amy.Vacation(20);
		Amy.Vacation(100);
	}	
}
