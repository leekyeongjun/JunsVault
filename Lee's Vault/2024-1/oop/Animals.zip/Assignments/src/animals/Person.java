package animals;

public interface Person {
    public void control(Animal animal);
    public void showInfo();
}
