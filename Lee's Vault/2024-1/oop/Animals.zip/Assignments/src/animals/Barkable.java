package animals;

public interface Barkable {
    public String bark();
}