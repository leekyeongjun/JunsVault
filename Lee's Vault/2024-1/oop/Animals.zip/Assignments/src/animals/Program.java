package animals;

public class Program {
	public static void main(String[] args) {
		Dog dog = new Dog();
		Tiger tiger = new Tiger();
		Turtle turtle = new Turtle();

		Animal[] animal = new Animal[3];
		animal[0] = dog;
		animal[1] = tiger;
		animal[2] = turtle;
        
        Person person = new Person() {
            private int hp = 100;

            @Override
            public void control(Animal animal) {
                if (animal instanceof Tiger) {
                    hp -= 80;
                } else if (animal instanceof Dog) {
                    hp -= 10;
                }
                System.out.println("You have overpowered the " + animal.getName());
            }

            @Override
            public void showInfo() {
                System.out.println("Person's hp: " + hp);
            }
        };

        showResult(animal, person);
    }

    public static void showResult(Animal[] animals, Person person) {
        for (int i = 0; i<animals.length; i++) {
        	Animal animal = animals[i];
            System.out.println("Animal" + (i+1) +":"+ animal.getName());
            if (animal instanceof Barkable) {
                System.out.println("Animal" + (i+1) + " barked " + ((Barkable) animal).bark());
            }
            person.control(animal);
            person.showInfo();
        }
    }
}
