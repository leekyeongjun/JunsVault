package animals;

public class Turtle extends Animal {
    public Turtle() {
        super("Turtle");
    }
}
