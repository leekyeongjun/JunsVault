package Assignment1_code_Leekyeongjun_2019092824;

public interface IFileHandler {
	PizzaStore InitPizzaStore(String fileLocation);
	void writeToFile(String fileLocation, String text);
}
