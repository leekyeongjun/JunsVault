package Assignment1_code_Leekyeongjun_2019092824;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;

public class TXTHandler implements IFileHandler{
	
	@Override
	public PizzaStore InitPizzaStore(String fileLocation) {
	    
	    if (!fileLocation.endsWith(".txt")) {
	        throw new IllegalArgumentException("Error : This file is not a TXT file.");
	    }
	    
	    Scanner inputStream = null;
	    try {
	        inputStream = 
	                new Scanner(new FileInputStream(fileLocation));
	        
	    }
	    catch(FileNotFoundException e) {
	        System.out.println("Error : Cannot found " + fileLocation);
	        return null;
	    }
	    
	    double money = 0;
	    int mushroom = 0, peperoni = 0, cheese = 0;
	    
	    while(inputStream.hasNextLine()) {
	        try {
	            String s = inputStream.nextLine();
	            String line = s;
	            String[] parts = line.split(";", -1);
	            if (parts.length != 2) {
	                throw new IllegalArgumentException("Wrong Order format: " + line);
	            }
	            String key = parts[0].trim();
	            String value = parts[1].trim();
	            
	            switch (key) {
	                case "Money":
	                    money = Double.parseDouble(value);
	                    break;
	                case "Mushroom":
	                    mushroom = Integer.parseInt(value);
	                    break;
	                case "Peperoni":
	                    peperoni = Integer.parseInt(value);
	                    break;
	                case "Cheese":
	                    cheese = Integer.parseInt(value);
	                    break;
	                default:
	                    throw new IllegalArgumentException("Unknown variable: " + key);
	            }
	        }
	        catch (IllegalArgumentException e) {
	            System.out.println("Error : " + e.getMessage());
	            return null;
	        }
	    }
	    return new PizzaStore(money, mushroom, peperoni, cheese);
	}

	@Override
	public void writeToFile(String fileLocation, String text) {
	    
	    if (!fileLocation.endsWith(".txt")) {
	        throw new IllegalArgumentException("Error : This file is not a TXT file.");
	    }
	    
	    // Text format: "Money/Mushroom/Peperoni/Cheese", delimiter is "/"
	    String[] parts = text.split("/");
	    if (parts.length != 4) {
	        throw new IllegalArgumentException("Error : The text format is incorrect.");
	    }

	    // Parse each part
	    double money = Double.parseDouble(parts[0]);
	    int mushroom = Integer.parseInt(parts[1]);
	    int peperoni = Integer.parseInt(parts[2]);
	    int cheese = Integer.parseInt(parts[3]);

	    // Prepare the content in the desired format
	    String content = String.format(
	        "Money;%.2f\nMushroom;%d\nPeperoni;%d\nCheese;%d",
	        money,
	        mushroom,
	        peperoni,
	        cheese
	    );

	    // Write to file
	    try (PrintWriter writer = new PrintWriter(new FileOutputStream(fileLocation))) {
	        writer.print(content);
	    } catch (FileNotFoundException e) {
	        e.printStackTrace();
	        System.out.println("Fatal Error : An error occurred while trying to write to the file: " + fileLocation);
	        System.exit(0);
	    }
	}

}
