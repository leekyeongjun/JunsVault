package Assignment1_code_Leekyeongjun_2019092824;

public class PizzaStore {
	private double cash;
	private Order currentOrder;
	private int peperoniStock;
	private int mushroomStock;
	private int cheeseStock;
	
	PizzaStore() {
		cash = 2.5;
		peperoniStock = 1;
		mushroomStock = 1;
		cheeseStock = 1;
	}
	
	public void addCash(double amount) {
		if(amount >= 0) cash += amount;
	}
	
	public void createOrder(int pizzaSize, boolean hasPeperoni, boolean hasMushrooms, boolean hasCheese){
		currentOrder = new Order();
		
		boolean availableOrder = true;
		
		int tmpPep = peperoniStock;
		int tmpMus = mushroomStock;
		int tmpChe = cheeseStock;
		
		if(hasPeperoni && availableOrder) {
			if(peperoniStock >= 1){peperoniStock -= 1;}
			else availableOrder = false;
		}
			
		if(hasMushrooms && availableOrder) {
			if(mushroomStock >= 1) {mushroomStock -= 1;} 
			else availableOrder = false;
		}
			
		if(hasCheese && availableOrder) {
			if(cheeseStock >= 1) {cheeseStock -= 1;}
			else availableOrder = false;
		}
		
		if(availableOrder) {
			currentOrder.addPizza(pizzaSize, hasPeperoni, hasMushrooms, hasCheese);
			System.out.println(currentOrder.toString());
			addCash(currentOrder.calculateOrderPrice());
		}
		else {
			System.out.println("The order is Not Available.");
			peperoniStock = tmpPep;
			mushroomStock = tmpMus;
			cheeseStock = tmpChe;
		}
	}
	
	public void restockPeperoni(int amount) {
		double price = amount * 1;
		if(cash >= price) {
			cash -= price;
			peperoniStock += amount;
			System.out.println(amount + " of peperoni purchased. Your current Cash is " + cash);
		}
		else {
			System.out.println("Not enough Cash. Your current cash is " + cash + " and the price is " + price );
		}
	}
	
	public void restockMushrooms(int amount) {
		double price = amount * 1.5;
		if(cash >= price) {
			cash -= price;
			mushroomStock += amount;
			System.out.println(amount + " of mushrooms purchased. Your current Cash is " + cash);
		}
		else {
			System.out.println("Not enough Cash. Your current cash is " + cash + " and the price is " + price );
		}
	}
	
	public void restockCheese(int amount) {
		double price = amount * .75;
		if(cash >= price) {
			cash -= price;
			cheeseStock += amount;
			System.out.println(amount + " of peperoni purchased. Your current Cash is " + cash);
		}
		else {
			System.out.println("Not enough Cash. Your current cash is " + cash + " and the price is " + price );
		}
	}
	
	public String toString() {
		String ret = "PizzaStore : cash: $" + cash + ", peperoni:" + peperoniStock + ", mushrooms:" + mushroomStock+ ", cheeses:" + cheeseStock +".";
		return ret;
	}
}
