package Assignment1_code_Leekyeongjun_2019092824;
import java.util.Scanner;

public class MainClass {
	
	public void showErrorMsg(int errcode) {
		String msg;
		if(errcode == 0) {
			// Number error.
			// if size has unavailable size, than this message appears.
			msg = "Unavailable Size, Please Retry.";
		}
		else if(errcode == 1) {
			// Command error.
			// if user has typed unavailable command, than this message appears.
			msg = "Unavailable Command, Please Retry.";
		}
		else if(errcode == 2){
			// Ingredient error.
			// if there is no Ingredients in Pizza, than this message appears.
			msg = "Pizza has no Ingredients. Please Retry.";
		}
		else {
			// Unknown error.
			// This should not be appeared.
			msg = "ErrorCode Index error.";
		}
		System.out.println("[Error] : " + msg);
	}
	
	public void selectAction(PizzaStore store, Scanner input) {
		
		int cmd = 0;
		System.out.println(store.toString());
		System.out.println("What would you like to do:");
		System.out.println("1: Place an order, 2: buy ingredients");
		
		cmd = input.nextInt();
		input.nextLine();
		
		while(!(cmd == 1 || cmd == 2)) {
			showErrorMsg(1);
			cmd = input.nextInt();
			input.nextLine();
		}
		
		if(cmd == 1) {
			placeOrder(store, input);
		}
		else if(cmd == 2) {
			buyIngredients(store, input);
		}

	}
	
	public void placeOrder(PizzaStore store, Scanner input) {
	    int size;
	    boolean hasPep= false, hasMus = false, hasChe = false;
	    System.out.println("What size pizza do you want?");
	    
	    size = input.nextInt();
	    
	    input.nextLine(); // flush nextLine after nextInt();
	    while(size < 0) {
	    	showErrorMsg(0);
	        size = input.nextInt();
	        input.nextLine(); // flush nextLine after nextInt();
	    }
	    
	    hasPep = selectIngredient(store, input, "peperoni");
	    hasMus = selectIngredient(store, input, "mushrooms");
	    hasChe = selectIngredient(store, input, "cheese");
	    
	    while(hasPep == false && hasMus == false && hasChe == false) {
	    	showErrorMsg(2);
		    
		    hasPep = selectIngredient(store, input, "peperoni");
		    hasMus = selectIngredient(store, input, "mushrooms");
		    hasChe = selectIngredient(store, input, "cheese");
	    }
	    
	    store.createOrder(size, hasPep, hasMus, hasChe);
	}

	public boolean selectIngredient(PizzaStore store, Scanner input, String label) {
	    String cmd;
	    System.out.println("Do you want "+ label +" on your pizza? Y/N");
	    cmd = input.nextLine();
	    while(!(cmd.toUpperCase().equals("Y") || cmd.toUpperCase().equals("N"))) {
	    	showErrorMsg(1);
	        cmd = input.nextLine();
	    }
	    
	    if(cmd.toUpperCase().equals("Y")) {
	        return true;
	    }else return false;
	    
	}

	public void buyIngredients(PizzaStore store, Scanner input) {
		int cmd;
		
		System.out.println("What ingredients do you want to buy?");
		System.out.println("1: peperoni, 2: mushrooms, 3: cheese, 4: none.");
		
		cmd = input.nextInt();
		while(cmd < 1 || cmd >= 5) {
			showErrorMsg(1);
			cmd = input.nextInt();
			input.nextLine();
		}
		
		if(cmd == 1) {
			store.restockPeperoni(1);
		}
		if(cmd == 2) {
			store.restockMushrooms(1);
		}
		if(cmd == 3) {
			store.restockCheese(1);
		}
		if(cmd == 4) {
			store.addCash(1);
		}
		
	}
	public static void main(String[] args) {
		Scanner scanner =  new Scanner(System.in);
		PizzaStore myStore = new PizzaStore();
		MainClass mainClassInstance = new MainClass();
		
		while(true) {
			mainClassInstance.selectAction(myStore, scanner);
		}
	}
}
