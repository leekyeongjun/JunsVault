package Assignment1_code_Leekyeongjun_2019092824;

public class Order {
	private Pizza pizza;
	
	Order(){
	}
	
	public void addPizza(int size, boolean hasPeperoni, boolean hasMushrooms, boolean hasCheese) {
		pizza = new Pizza(size, hasPeperoni, hasMushrooms, hasCheese);
	}
	
	public double calculateOrderPrice() {
		double price = pizza.getPrice();
		return price;
	}
	
	public String toString() {
		String ret;
		// ret = pizza.toString();
		ret = "Your total will be $" + calculateOrderPrice() + ".";
		return ret;
	}
}
