package account;
import java.time.*;

public class Account {
	private String name;
	private double yearlyInterest;
	private double balance;
	private LocalDate created; 
	
	
	public Account(String _name, double _yearlyInterest, LocalDate _created) {
		name = _name;
		yearlyInterest = _yearlyInterest;
		created = _created;
		balance = 0;
	}
	
	public double getBalance() {
		return balance;
	}
	public LocalDate getCreated() {
		return created;
	}
	
	public void increaseYearlyInterest(int byPercent) {
		double tmpYearlyInterest = yearlyInterest;
		tmpYearlyInterest += byPercent;
		yearlyInterest = tmpYearlyInterest;
	}
	
	public void receiveIncome(double income) {
		balance += income;
		
	}
	
	public void receiveInterest() {
		double interest = (balance * (yearlyInterest/100)) / 12;
		receiveIncome(interest);
	}
	
	public String toString() {
		String ret = "이름 : " + name + " 연이자 : " + yearlyInterest + " 잔고 : " + balance + " 가입일 : " + created.toString();
		return ret;
	}
}
