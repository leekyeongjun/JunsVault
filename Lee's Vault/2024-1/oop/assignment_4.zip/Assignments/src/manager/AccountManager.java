package manager;
import account.Account;
import java.time.*;
import java.util.Random;

public class AccountManager {
	
	public static void main(String args[]) {
		Random rand = new Random();
		int myLuckyNumber = rand.nextInt(10);
		LocalDate created = LocalDate.of(2021, 12, 1);
		Account myAccount = new Account("Lee", 5, created);
		System.out.println(myAccount.toString());
		
		
		int monthsAfter = 0;
		while(myAccount.getBalance() <= 10000) {
			monthsAfter ++;
			//System.out.println((monthsAfter % 12) + "월이 되었습니다.");
			myAccount.receiveIncome(100);
			myAccount.receiveInterest();
			//System.out.println("현재 잔고 :" + myAccount.getBalance());
	
			if(monthsAfter % 12 == 1) {
				int ival = rand.nextInt(10);
				if(ival == myLuckyNumber) {
					System.out.println("이벤트 당첨!");
					myAccount.receiveIncome(100);
				}
			}
			
			if(monthsAfter == 36) {
				myAccount.increaseYearlyInterest(2);
				System.out.println("가입 후 3년이 지나 이자율이 2% 인상되었습니다.");
			}
		}
		System.out.println(myAccount.toString() + ", 1억 모으기 끝 : " + created.plusMonths(monthsAfter).toString());
	}
}
